$(document).ready(function() {
	$("#hi").css('color', 'red');
});