// This is the distance from the top of the screen
var margintop = "50px";


// true = 24hours, false = 12hour
var twentyfourhours = true;s


// If true this includes the '0' before times below 10 e.g. if time '9:00' 'true' sets to '09:00'
var zero = true; 


// Temperature units: "f" or "c"
var unit = "f"; 


// Select location using WOEID - The default "2388327" is for Cupertino, CA
var woeid = "2388327"; 